# modXNA
This repository contains the main driver script for modXNA.

Reference: [Love et. al, "modXNA: A Modular Approach to Parametrization of Modified Nucleic Acids for Use with Amber Force Fields", JCTC, 2024, 20, 21, 9354-9363](https://pubs.acs.org/doi/10.1021/acs.jctc.4c01164)

See <https://modxna.chpc.utah.edu/> for more details.
