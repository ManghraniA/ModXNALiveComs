import pandas as pd

def generate_load_save_commands_final(input_csv_file, output_txt_file):
    # Load the CSV file containing the residue codes
    df = pd.read_csv(input_csv_file)
    df['ID'] = df['ID'].astype(str)
    
    # Filter out rows where 'Residue name' is missing
    df_clean = df.dropna(subset=['Residue name'])
    
    # Generate the Loadoff command: Loadoff {ID}/{code}.lib
    load_command = f'Loadoff {{ID}}/{{code}}.lib'
    # Generate the Saveoff command: Saveoff {code} RNA_Tx.lib
    save_command = f'Saveoff {{code}} RNA_Tx.lib'
    
    commands = []
    for index, row in df_clean.iterrows():
        code = row['Residue name']
        ID = row['ID']
        
        # Only proceed if 'code' is a valid 3-letter string
        if isinstance(code, str) and len(code) == 3:
            commands.append(load_command.format(ID=ID, code=code))
            commands.append(save_command.format(code=code))
    
    # Add the 'quit' command at the end
    commands.append('quit')

    # Write the commands to the output file
    with open(output_txt_file, 'w') as f:
        f.write('\n'.join(commands))

    print(f'Successfully generated commands and saved to {output_txt_file}')

if __name__ == "__main__":
    # Define input and output file names
    input_file = "MasterList.csv"
    output_file = "create-RNA_Tx-lib.tleap"
    
    # Run the function
    generate_load_save_commands_final(input_file, output_file)