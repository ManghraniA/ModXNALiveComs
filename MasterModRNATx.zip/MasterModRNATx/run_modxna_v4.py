import pandas as pd
from pathlib import Path
import subprocess
import random 
import string 

# --- input and output files ---
INPUT_CSV = "input.csv"
OUTPUT_CSV = "MasterList.csv"
BUILD_DIR_NAME = "." 

def generate_random_3_letter_code():
    """Generates a random 3-letter code (e.g., 'XYZ')."""
    code_length = 3
    # Generates a string of 3 random uppercase ASCII letters
    return ''.join(random.choices(string.ascii_uppercase, k=code_length))

def process_residues():
    """
    Main function to load data, count modifications, generate unique 3-letter codes,
    process each residue, and execute the modXNA script.
    """
    if not Path(INPUT_CSV).exists():
        print(f"Error: Input file '{INPUT_CSV}' not found.")
        return

    # 1. Load the data and count modifications
    print(f"Loading data from {INPUT_CSV}...")
    df = pd.read_csv(INPUT_CSV)
    num_modifications = len(df)
    
    # Check for required columns
    required_cols = ['ID', 'Notes', 'Backbone', 'Sugar', 'Base']
    for col in required_cols:
        if col not in df.columns:
            print(f"Error: Input CSV must contain a '{col}' column.")
            return

    # --- Generate 'N' unique 3-letter codes ---
    print(f"\n## Generating {num_modifications} Unique 3-Letter Codes")
    
    existing_codes = set()
    new_residue_names = []
    
    # Generate all required unique codes
    while len(new_residue_names) < num_modifications:
        
        
        unique_code = generate_random_3_letter_code()
        
        # If the code clashes, loop until a new, unique 3-letter code is found.
     
        while unique_code in existing_codes:
            unique_code = generate_random_3_letter_code()

        # Add the guaranteed unique 3-letter code to our lists
        existing_codes.add(unique_code)
        new_residue_names.append(unique_code)

    # Pre-populate the 'Residue name' column with the generated unique codes
    df['Residue name'] = new_residue_names
    print(f"Generated and assigned {len(new_residue_names)} unique residue codes (first 5: {new_residue_names[:5]}).")
    
    # List to hold the residue names
    final_residue_names = list(new_residue_names) 

    print(f"\nProcessing {len(df)} residues. Build directories will be created directly in the Current Working Directory.")
    
    # 2. Iterate and process each residue
    for index, row in df.iterrows():
        
        # Get the pre-assigned code
        residue_3letter_code = row['Residue name']
        
        # --- Use ID for directory naming ---
        dir_name = f"{row['ID']}"
        build_path = Path(BUILD_DIR_NAME) / dir_name
        build_path.mkdir(parents=True, exist_ok=True)
        
        in_modxna_path = build_path / "in.modxna"
        
        # 3. Create the in.modxna input file
        modxna_content = (
            f"{row['Backbone']} {row['Sugar']} {row['Base']} \n"
        )
        try:
            with open(in_modxna_path, 'w') as f:
                f.write(modxna_content)
        except IOError:
            print(f"Error writing {in_modxna_path}")
            final_residue_names[index] = None 
            continue

        print(f"\n[Processing ID #{row['ID']}] | Code: **{residue_3letter_code}**")
        
       # --- EXECUTION SCRIPT START---
        
        # Command includes the -m flag with the generated 3-letter code
        command = [
            "bash", 
            "../../modXNA/modxna.sh", 
            "-i", in_modxna_path.name,
            "-m", residue_3letter_code 
        ]
        
        # Check the 'Notes' field to append the appropriate flag
        notes = str(row['Notes']).lower()
        
        if '5\' terminal' in notes:
            command.append("--5cap")
            terminal_type = "5' terminal"
        elif '3\' terminal' in notes:
            command.append("--3cap")
            terminal_type = "3' terminal"
        else:
            terminal_type = "central residue" 

        print(f"  [TYPE] Identified as: {terminal_type}")
        print(f"  [EXECUTING] {' '.join(command)} (in directory {build_path.resolve()})")
        
        try:
            # 4. Execute the modXNA script
            result = subprocess.run(
                command, 
                cwd=build_path, 
                check=True, 
                capture_output=True, 
                text=True
            )
            print(f"  [EXECUTION SUCCESS] Returned code: {result.returncode}")
            
            # 5. Check for the .lib file
            lib_file = next(build_path.glob('*.lib'), None)
            
            if lib_file:
                extracted_code = lib_file.stem
                if extracted_code != residue_3letter_code:
                    print(f"  [WARNING] Expected .lib file name to be '{residue_3letter_code}.lib', but found '{lib_file.name}'. Using extracted name.")
                
                print(f"  [RESULT] Extracted Residue Code: {extracted_code}")
                final_residue_names[index] = extracted_code 
            else:
                print("  [ERROR] Script ran successfully, but no .lib file was found.")
                if result.stdout:
                    print(f"    --- modxna.sh STDOUT ---\n{result.stdout.strip()}")
                if result.stderr:
                    print(f"    --- modxna.sh STDERR ---\n{result.stderr.strip()}")
                if not result.stdout and not result.stderr:
                    print("    (Script produced no stdout or stderr.)")
                final_residue_names[index] = None 
                
        except subprocess.CalledProcessError as e:
            print(f"  [ERROR] Script execution failed in {dir_name}. Exit Code: {e.returncode}")
            if e.stdout:
                print(f"    --- modxna.sh STDOUT ---\n{e.stdout.strip()}")
            if e.stderr:
                print(f"    --- modxna.sh STDERR ---\n{e.stderr.strip()}")
            final_residue_names[index] = None 
        except FileNotFoundError:
            print(f"  [FATAL ERROR] Command or script not found. Check if 'modxna.sh' exists in the parent directory.")
            final_residue_names[index] = None 
            
    
    # 6. Update the DataFrame with the *final* list (in case of failures)
    df['Residue name'] = final_residue_names
    
    # 7. Save the final list
    df.to_csv(OUTPUT_CSV, index=False)
    
    print("\n--- FINAL SUMMARY ---")
    print(f"Successfully processed {len(df)} entries.")
    print(f"Final data saved to: {OUTPUT_CSV}")
    print("\nFirst 5 entries with Residue Name:")
    print(df[['ID', 'Residue name', 'Backbone', 'Sugar', 'Base', 'Details of fragments']].head())


if __name__ == "__main__":
    process_residues()
